//--------coding by chenyan
//2012.1.12

(function($) {
	
	jQuery.fn.extend({
		marqueeOn: function(boxSpeed,boxInter) {	
			var _this=$(this);
			var boxCont,boxThis,boxUnit,boxOrg,boxClone,boxTimer,boxLeft,boxIsTimer;			
			resetThis();
			
			function resetThis(){
				boxSpeed=boxSpeed || 0.5;//�����ٶ�
				boxInter=boxInter || 15;//�������������ԽСԽ����
				boxCont=_this.children();
				boxThis=boxCont.children();
				boxUnit=0;
				boxOrg=0;
				boxLeft=0;	
				boxIsTimer=false;
						
				boxThis.each(function(){
					boxOrg=boxUnit+=$(this).outerWidth(true);
				});	
				boxClone=Math.floor( _this.width()*2/boxUnit);
				for(var i=1; i<=boxClone; i++){
					boxCont.append(boxThis.clone());
					boxUnit+=boxOrg; 
				}//end for	
				boxThis=boxCont.children();
				//alert(boxOrg);
				//alert(boxThis.length);
				boxCont.width(boxUnit+boxOrg);	
				_this.bind('mouseenter',boxMouseEnter);
				_this.bind('mouseleave',boxMouseLeave);
				boxTimerFunc();		
			}//end func
			
			function boxMouseEnter(){
				clearInterval(boxTimer);
				boxIsTimer=false;
			}//end func
			function boxMouseLeave(){
				if(!boxIsTimer){
					boxIsTimer=true;
					boxTimerFunc();
				}//end if
			}//end func
			
			function boxTimerFunc(){
				clearInterval(boxTimer);
				boxTimer=setInterval(btnRollFunc,boxInter);
			}//end timer
						
			function btnRollFunc(){
				boxThis=boxCont.children();
				var boxUnit=boxThis.first().outerWidth(true);
				boxLeft-=boxSpeed;	
				if(boxLeft<=-boxUnit){
					boxThis.last().after(boxThis.first());
					boxLeft=boxUnit+boxLeft;
				}//end if
				boxCont.css("left",boxLeft);
			}//end func

		}//end fn
		
	});//end extend
})(jQuery);//�հ�