//--------coding by chenyan
//2012.1.12

(function($) {
	jQuery.fn.extend({
		textLeftOn: function(txtMax) {	
			var _this=$(this);
			var txtNow,txtLast,txtInput,txtLeft,txtSign,txtSign1,txtSign2,txtTimer;			
			resetThis();
			
			function resetThis(){
				txtMax=txtMax || 140;  //Ĭ�ϸ�ֵ
				txtNow=0;
				txtLast=0;
				txtInput=_this.find("textarea");
				txtLeft=_this.find(".txtLeft");
				txtSign=_this.find(".txtSign");
				txtSign1="���������ԣ�����������";
				txtSign2="���������ԣ��Ѿ�����";
				txtLeftFunc();
				txtTimerSet();
				
				_this.bind("maxSet",maxSetFunc);		
			}//end func			
			
			function maxSetFunc(event,value1){
				txtMax=value1;
				txtLast=0;
				txtLeftFunc();
			}//end func
			
			function txtTimerSet(){
				clearInterval(txtTimer);
				txtTimer=setInterval(txtLeftFunc,500);
			}//end func
			
			function txtLeftFunc(){
				txtNow=Math.floor(txtLenMath(txtInput.val())/2);
				if(txtNow!=txtLast){
					if(txtMax-txtNow>=0){txtLeft.text(txtMax-txtNow);txtSign.html(txtSign1);}else{txtLeft.html(txtNow-txtMax);txtSign.html(txtSign2);}
					txtLast=txtNow;
				}//end if
			}//end func
			
			function txtLenMath(str) {
				var byteLen = 0,
				len = str.length;
				if (str) {
					for (var i = 0; i < len; i++) {
						if (str.charCodeAt(i) > 255) {
							byteLen += 2;
						}
						else {
							byteLen++;
						}
				}
					return byteLen;
				}
				else {
					return 0;
				}
			}//end func

		},//end fn
		
		textLeftSet: function(txtMax) {
			txtMax=txtMax || 140;  //Ĭ�ϸ�ֵ
			$(this).trigger('maxSet',[txtMax]);
		}//end fn
		
	});//end extend
	
})(jQuery);//�հ�