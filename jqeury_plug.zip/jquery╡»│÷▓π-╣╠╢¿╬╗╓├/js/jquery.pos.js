//--------coding by chenyan
//2012.1.10

(function($) {	
	jQuery.fn.extend({
		
		posOn: function(typeX,posX,typeY,posY) {	
			var _this=$(this);
			var isIE6, popClose;
			resetThis();
			
			function resetThis(){
				posY=posY || 0; //Ĭ�ϸ�ֵ
				typeY=typeY || "middle";//0�������У�1=�ϣ�2=��
				posX=posX || 0;//Ĭ�ϸ�ֵ
				typeX=typeX || "middle";//0�������У�1=��2=��
				isIE6=$.browser.msie && $.browser.version=="6.0";
				popClose=_this.find(".close")
				
				if(isIE6){_this.css("position","absolute");}else{_this.css({"position":"fixed"});}//end not ie6
				_this.show();
				posReset();
				_this.bind('resize',posReset);//end bind
				_this.one('close',posHide);//end bind
				popClose.one('click',posHide);//end bind
				$(window).bind('resize',posReset);//end bind
				$(window).bind('scroll',posReset);//end bind
			}//end func				
			
			function posHide(){
				$(window).unbind('resize',posReset);
				$(window).unbind('scroll',posReset);
				_this.unbind('resize',posReset);
				_this.hide();
			}//end func
			
			function posReset(){
				switch(typeX){
					case "middle":
						var midX=$(window).width()/2-_this.outerWidth()/2;
						if(isIE6){_this.css("left",$(document).scrollLeft()+midX);}else{_this.css("left",midX);}
					break;
					case "left":
						if(isIE6){_this.css("left",$(document).scrollLeft()+posX);}else{_this.css("left",posX);}
					break;
					case "right":
						if(isIE6){_this.css("left",$(document).scrollLeft()+$(window).width()-_this.outerWidth()-posX);}else{_this.css("left",$(window).width()-_this.outerWidth()-posX);}
					break;
					default:
					break;
				}//end switch typeX
				
				switch(typeY){
					case "middle":
						var midY=Math.floor($(window).height()/2-_this.outerHeight()/2);
						if(isIE6){_this.css("top",$(document).scrollTop()+midY);}else{_this.css("top",midY);}
					break;
					case "top":
						if(isIE6){_this.css("top",$(document).scrollTop()+posY);}else{_this.css("top",posY);}
					break;
					case "bottom":
						if(isIE6){_this.css("top",$(document).scrollTop()+$(window).height()-_this.outerHeight()-posY);}else{_this.css("bottom",posY);}
					break;
					default:
					break;
				}//end switch typeY		
				
			}//end func
		},//end fn	
		
		posOff: function() {
			$(this).trigger('close');
		}//end fn	
			
	});//end extend	
})(jQuery);//�հ�