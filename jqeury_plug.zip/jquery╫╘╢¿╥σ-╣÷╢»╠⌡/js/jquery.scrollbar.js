//--------coding by chenyan
//2012.1.12

(function($) {

jQuery.fn.extend({
	scrBarOn: function(scrSp) {	
		var _this=$(this);
		var scrCont,scrPanel,scrUp,scrDown,scrZone,scrBar,mX,mY,isMouseOver,isMouseDrag,scrLineT,scrDisHt,scrBarHt,scrLineB,scrYTar,scrCan,scrContHt,scrContHtLast,scrScrollTimer,scrIsScrollTimer,scrInter;
		resetThis();
			
		function resetThis(){
			scrSp=scrSp||10;
			scrCont=_this.children(".scrCont");
			scrPanel=_this.children(".scrPanel");
			scrUp=scrPanel.children(".scrUp");
			scrDown=scrPanel.children(".scrDown");
			scrZone=scrPanel.children(".scrZone");
			scrBar=scrPanel.children(".scrBar");
			scrLineT=scrZone.position().top;
			scrDisHt=_this.height();//�ɼ�����߶�
			scrZoneHt=scrDisHt-scrUp.height()-scrDown.height();//�ɻ����߶�
			scrBarHt=scrBar.height();
			scrLineB=scrLineT+scrZoneHt-scrBarHt;//��������
			scrContHt=scrCont.outerHeight();//�������ݸ�
			scrContHtLast=scrContHt;//����������һ�θ�			
			
			scrUp.css({"top":0});
			scrDown.css({"top":scrUp.height()+scrZoneHt});
			scrZone.css({"top":scrUp.height(),"height":scrZoneHt});
			resizeFunc();
			scrInterFunc();
			
			
			_this.bind("scrUp",scrUpFunc);
			_this.bind("scrDown",scrDownFunc);
			$(document).bind('mouseup',scrBarMouseUp);
			_this.bind('mousewheel',_this_mousewheel);
			_this.bind('mouseenter',_this_mouseenter);
			_this.bind('mouseleave',_this_mouseleave);
			_this.bind('mousemove',_this_mousemove);
			scrBar.bind('mousemove',scrBar_mousemove);
			scrZone.bind('mousedown',scrZone_mousedown);
			scrUp.bind('mouseleave',scrUpDown_mouseleave);
			scrUp.bind('mousedown',scrUp_mousedown);
			scrUp.bind('mouseup',scrUpDown_mouseup);
			scrDown.bind('mouseleave',scrUpDown_mouseleave);
			scrDown.bind('mousedown',scrDown_mousedown);
			scrDown.bind('mouseup',scrUpDown_mouseup);			
		}//end func	
		
		function scrUpFunc(event){
			if(scrCan){
				scrYTar-=scrSp;
				scrollFunc();
			}//end if
		}//end func
		
		function scrDownFunc(event){
			if(scrCan){
				scrYTar+=scrSp;
				scrollFunc();
			}//end if
		}//end func
		
		function _this_mousewheel(event, delta){
			if(scrCan){
				delta=delta/Math.abs(delta)*scrSp;
				scrYTar-=delta;
				scrollFunc();
			}//end if 
		}//end func
		function _this_mouseenter(event){
			if(scrCan){
				isMouseOver=true;
				$(document).bind('mousewheel',scrBarMousewheel);//��ֹ����Ĭ����Ϊ����
			}//end if  
		}//end func
		function _this_mouseleave(event){
			if(scrCan){
				isMouseOver=false;
				$(document).unbind('mousewheel',scrBarMousewheel);//�ָ�����Ĭ����Ϊ����
			}//end if 
		}//end func
		function _this_mousemove(event){
			mX=event.pageX;
			mY=event.pageY; 
			startDrag();
		}//end func
		function scrBar_mousemove(event){
			$(this).mousedown(function(){isMouseDrag=true;});
		}//end func
		function scrZone_mousedown(event){
			scrYTar=mY-_this.offset().top;
			scrollFunc();
		}//end func
		function scrUpDown_mouseleave(event){
			scrIsScrollTimer=false;
			clearInterval(scrScrollTimer);
		}//end func
		function scrUpDown_mouseup(event){
			scrIsScrollTimer=false;
			clearInterval(scrScrollTimer);
		}//end func
		function scrUp_mousedown(event){
			if(!isMouseDrag && !scrIsScrollTimer){ 
				scrIsScrollTimer=true;
				scrScrollTimer=setInterval(function(){
					scrYTar-=scrSp;
					scrollFunc();
				},60);	
			}//end if	
			mouseSelectOff();
		}//end func
		function scrDown_mousedown(event){
			if(!isMouseDrag && !scrIsScrollTimer){ 
				scrIsScrollTimer=true;
				scrScrollTimer=setInterval(function(){
					scrYTar+=scrSp;
					scrollFunc();
				},60);	
			}//end if	
			mouseSelectOff();
		}//end func		
		
		function scrInterFunc(){
			scrInter=setInterval(scrListener,500);
		}//end func
		
		function scrListener(){
			scrContHt=scrCont.outerHeight();
			if(scrContHtLast!=scrContHt){
				scrContHtLast=scrContHt;
				resizeFunc();
			}//end if
		}//end func
		
		function resizeFunc(){
			isMouseOver=false;
			isMouseDrag=false;
			scrYTar=0;
			scrCont.css("top",0);
			scrIsScrollTimer=false;	
			if(scrContHt<=scrDisHt){
				scrCan=false;
				scrPanel.hide();
			}//end if
			else{
				scrCan=true;
				scrPanel.show();
			}//end else	
			scrBar.css({"top":scrUp.height()});			
		}//end func
		
		function scrBarMouseUp(){
			isMouseDrag=false;  
			mouseSelectOn();
		}//end func
		
		function scrBarMousewheel(event){
			event.preventDefault();
		}//end func
	
		function startDrag(){
			if(isMouseDrag && isMouseOver){
				scrYTar=mY-_this.offset().top;
				scrollFunc();
				mouseSelectOff();
			 }//end if
		}//end func  	
	   
		function scrScrollTimerSet(){
			scrScrollTimer=setInterval(function(){
				scrollFunc();
			},60);
		}//end func   
	   
		function scrollFunc(){
				scrYTar=scrYTar>scrLineB?scrLineB:scrYTar;
				scrYTar=scrYTar<scrLineT?scrLineT:scrYTar;
				scrBar.css("top",scrYTar); 
				scrCont.css("top",-Math.floor(scrYTar-scrLineT)/(scrZoneHt-scrBarHt)*(scrContHt-scrDisHt));	
		}//end func   
		
		function mouseSelectOff(){
			document.onselectstart = function () { return false; };	//��ֹieѡȡ
			document.unselectable= "on";//��ֹOPERAѡȡ
			_this.css({"-moz-user-select":"none"});//��ֹFIREFXѡȡ
			$("body").css({"-webkit-user-select":"none"});//��ֹchromeѡȡ��
		}//end func
		
		function mouseSelectOn(){
			document.onselectstart = function () { return true; };//����IEѡȡ
			document.unselectable= "off";//����OPERAѡȡ
			_this.css({"-moz-user-select":"elements"});//����FIREFOXѡȡ
			$("body").css({"-webkit-user-select":"text"});//����CHROMEѡȡ
		}//end func	
	
	},//end fn
	
	scrBarUp: function() {
		$(this).trigger('scrUp');
	},//end fn
	
	scrBarDown: function() {
		$(this).trigger('scrDown');
	}//end fn
	
});//end extend

})(jQuery);//�հ�