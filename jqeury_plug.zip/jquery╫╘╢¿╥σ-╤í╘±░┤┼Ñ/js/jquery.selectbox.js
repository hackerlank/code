//--------coding by chenyan
//2012.1.12

(function($) {
	jQuery.fn.extend({
		selectboxOn: function(img1,img2,isRadio) {
			var _this=$(this);
			var selectbox;
			resetThis();
			
			function resetThis(){
				isRadio=isRadio || false;
				selectbox=_this.children("img");
				selectbox.attr("src",img1);
				selectbox.bind("click",selectbox_click);
			}//end func
			
			function selectbox_click(event){
				var _obj=$(event.target);
				var _id=_obj.index();
				if( _obj.attr("src") == img1 ){
					if(isRadio){selectbox.attr("src",img1);}//end if
					_obj.attr("src",img2);
					_obj.siblings().attr("checked",true);
					//_obj.siblings().show();//������
				}//end if
				else{
					if(!isRadio){_obj.attr("src",img1);}//end if
				}//end else
			}//end func
			
		}//end fn
	});//end extend
})(jQuery);//�հ�