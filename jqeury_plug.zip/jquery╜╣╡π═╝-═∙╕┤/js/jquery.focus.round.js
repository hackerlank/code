//--------coding by chenyan
//2012.1.12

(function($) {
		
	jQuery.fn.extend({
		focusRdOn: function(boxScrV,boxSpeed,boxDelay,boxNoAuto,btnNoHide) {	
			var _this=$(this);
			var boxMask,boxCont,boxThis,boxBtn,boxBtnL,boxBtnR,boxWd,boxHt,boxMax,boxesWd,boxesHt,boxDis,boxTar,boxTimer,boxNow,boxBtnThis,boxDir,boxShowNum,boxIsTimer;
			resetThis();
			
			function resetThis(){
				boxSpeed=boxSpeed || 1000;
				boxDelay=boxDelay || 5000;
				boxScrV=boxScrV || false;
				boxNoAuto=boxNoAuto || false;	
				btnNoHide=btnNoHide || false;
				boxMask=_this.children(".boxMask");
				boxCont=boxMask.children();
				boxThis=boxCont.children();
				boxBtn=_this.children(".boxBtn");
				boxBtnL=_this.children(".boxBtnL");
				boxBtnR=_this.children(".boxBtnR");
				boxWd=_this.width();
				boxHt=_this.height();
				boxMax=boxThis.length;//һ���м���ͼ
				boxesWd=boxMax*boxWd;//�ܳ���
				boxesHt=boxMax*boxHt;//�ܸ߶�
				boxTar=0;
				boxNow=1;
				boxDir=-1;
				boxShowNum=1;
				boxIsTimer=false;
				
				boxThis.width(boxWd).height(boxHt);
				boxMask.width(boxWd).height(boxHt);
				if(!boxScrV){boxCont.width(boxesWd);boxDis=boxesWd-boxWd;}else{boxCont.height(boxesHt);boxDis=boxesHt-boxHt;}
				
				for(var i=1; i<=boxMax;i++){
					boxBtn.append('<span>'+i+'</span>');
				}//end for
				boxBtnThis=boxBtn.children();				
				
				_this.bind("goto",boxGoto);
				_this.bind("prev",boxPrev);
				_this.bind("next",boxNext);
				boxBtnThis.bind('click',boxBtnThis_click);
				boxBtnThis.bind('mouseenter',boxMouseEnter);
				boxBtnThis.bind('mouseleave',boxMouseLeave);
				boxBtnL.bind('click',boxBtnL_click);
				boxBtnL.bind('mouseenter',boxMouseEnter);
				boxBtnL.bind('mouseleave',boxMouseLeave);
				boxBtnR.bind('click',boxBtnR_click);
				boxBtnR.bind('mouseenter',boxMouseEnter);
				boxBtnR.bind('mouseleave',boxMouseLeave);
				boxThis.bind('mouseenter',boxMouseEnter);
				boxThis.bind('mouseleave',boxMouseLeave);
				boxTimerFunc();
				boxBtnThis.first().click();
				boxBtnChange();
			}//end func
			
			function boxPrev(event){
				if(!boxCont.is(":animated") && boxDis>0 && boxNow > 1){	
					if(!boxNoAuto){boxTimerFunc();}
					boxNow--;
					boxDir=-1;
					boxMotion();
					boxBtnChange();
				}//end if
			}//end func
			
			function boxNext(event){
				if(!boxCont.is(":animated") && boxDis>0 && boxNow < boxMax){
					if(!boxNoAuto){boxTimerFunc();}
					boxNow++;
					boxDir=1;
					boxMotion();
					boxBtnChange();
				}//end if
			}//end func
			
			function boxGoto(event,value1){
				if(!boxCont.is(":animated") && boxDis>0){
					boxNow=value1;
					boxCont.stop(true);
					boxMotion();
					boxBtnChange();
				}//end if
			}//end func
			
			function boxBtnThis_click(event){
				var _obj=$(event.target);
				var _id=_obj.index();
				if(!boxCont.is(":animated") && boxDis>0){
					boxNow=_id+1; 
					boxCont.stop(true);
					boxMotion();
					boxBtnChange();
				}//end if
			}//end func
			function boxBtnL_click(event){
				if(!boxCont.is(":animated") && boxDis>0 && boxNow > 1){	
					boxNow--;
					boxDir=-1;
					boxMotion();
					boxBtnChange();
				}//end if
			}//end func
			function boxBtnR_click(event){
				if(!boxCont.is(":animated") && boxDis>0 && boxNow < boxMax){	
					boxNow++;
					boxDir=1;
					boxMotion();
					boxBtnChange();
				}//end if
			}//end func	
			function boxMouseEnter(){
				clearInterval(boxTimer);
				boxIsTimer=false;
			}//end func
			function boxMouseLeave(){
				if(!boxIsTimer){
					boxIsTimer=true;
					boxTimerFunc();
				}//end if
			}//end func
			
			function boxTimerFunc(){
				if(!boxNoAuto){
					clearInterval(boxTimer);
					boxTimer=setInterval(btnRollFunc,boxDelay);
				}//end if
			}
			
			function btnRollFunc(){
			if(!boxCont.is(":animated") && boxDis>0){		
				if(boxNow==1 || boxNow==boxMax){boxDir=-boxDir}
				if(boxDir==-1){ boxNow--;}else{boxNow++;}
				boxMotion();
				boxBtnChange();
			}//end if(!boxCont.is(":animated") && boxDis>0)
			}//end func
			
			function boxMotion(){
				if(!boxScrV){
					boxCont.animate({left:-(boxNow-1) * boxWd},boxSpeed);
				}//end if
				else{
					boxCont.animate({top:-(boxNow-1) * boxHt},boxSpeed);
				}//end else
			}//end func
			
			function boxBtnChange(){
				if(!btnNoHide){
					if(boxNow == 1){boxBtnL.hide();boxBtnR.show();}else if(boxNow == boxMax){boxBtnL.show();boxBtnR.hide();}else{boxBtnL.show();boxBtnR.show();}
				}//end if
				boxBtnThis.removeClass("now nor").eq(boxNow-1).addClass("now").siblings().addClass("nor");
			}//end func

		},//end fn
		
		focusRdGoto: function(boxId) {
			boxId=boxId||1;
			$(this).trigger('goto', [boxId]);
		},//end fn
		
		focusRdPrev: function() {
			$(this).trigger('prev');
		},//end fn
		
		focusRdNext: function() {
			$(this).trigger('next');
		}//end fn
		
	});//end extend
	
})(jQuery);//�հ�
