//--------coding by chenyan
//2012.1.12

(function($) {
	
	jQuery.fn.extend({
		selectOn: function(listMax) {	
			var _this=$(this);
			var selInput,selList,selOpt,isListOn,isListMouseDown,selNow,selMax,selHt,selHtTot,selBeg,selEnd,selDir;
			resetThis();
			
			function resetThis(){
				listMax=listMax||10;
				selInput=_this.children("input");
				selList=_this.children(".selList");
				selOpt=selList.children();
				isListOn=false;
				isListMouseDown=false;
				selNow=0;
				selHt=selOpt.outerHeight(true);
				selBeg=0;
				selEnd=listMax-1;
				selDir=1;

			
				selList.height(selHt*listMax);
				selInput.val(selOpt.first().text());
				
				_this.bind("selSet",selSetFunc);
				_this.bind('keydown',_this_keydown);
				_this.bind('keyup',_this_keyup);
				selList.bind('mousedown',selList_mousedown);
				selInput.bind('focus',selInput_focus);
				selInput.bind('click',selInput_click);
				selInput.bind('blur',selInput_blur);
				selOpt.bind('click',selOpt_click);
				selOpt.bind('mouseenter',selOpt_mouseenter);
			}//end func
			
			function selSetFunc(event,value1){
				selNow=value1;
				selCheck();
			}//end func
			
			function _this_keydown(event){
				selOpt.unbind('mouseenter',selOpt_mouseenter);
				switch(event.which){
						case 13:
							ListHide();
							selCheck();
						break;
						case 40:
							selNow++;
							selNow=selNow<=selMax-1?selNow:selMax-1;
							selOpt.removeClass("mouseover").eq(selNow).addClass("mouseover");
							if(isListOn){
								selList.scrollTop(selHt*(selNow+1)-selList.height());
							}//end if
							selCheck();
						break;
						case 38:
							selNow--;
							selNow=selNow>=0?selNow:0;
							selOpt.removeClass("mouseover").eq(selNow).addClass("mouseover");
							if(isListOn){
								selList.scrollTop(selHt*(selNow+1)-selList.height());
								//selList.scrollTop(selHt*selNow);
							}//end if
							selCheck();
						break;
						default:
						break;
				}//end switch
			}//end func
			
			function _this_keyup(event){
				selOpt.bind('mouseenter',selOpt_mouseenter);
			}//end func
			
			function selList_mousedown(event){
				isListMouseDown=true;
			}//end func
			
			function selInput_click(event){
				if(isListOn){ListHide();}else{ListShow();}
			}//end func
			function selInput_focus(event){
				selOpt=selList.children();
				selMax=selOpt.length;
			}//end func
			function selInput_blur(event){
				if(!isListMouseDown){ListHide();}	
			}//end func	
			
			function selOpt_click(event){
				selCheck();
				ListHide();
			}//end func
			
			function selOpt_mouseenter(event){
				var _obj=$(event.target);
				selNow=_obj.index();
				_obj.addClass("mouseover").siblings().removeClass("mouseover");
			}//end func
			
			function ListHide(){
				selList.hide();
				isListOn=false;
				isListMouseDown=false;
			}//end func
			
			function ListShow(){
				selList.show();
				isListOn=true;
				isListMouseDown=false;
				selNow=0;
				selOpt=selList.children();
				selMax=selOpt.length;
				selHtTot=selHt*selMax;
				selOpt.removeClass("mouseover").eq(selNow).addClass("mouseover");
			}//end func
			
			function selCheck(){
				selInput.val(selOpt.eq(selNow).text());
			}//end func

		},//end fn
		
		selectSet: function(value) {
			value=value||1;
			$(this).trigger('selSet',[value-1]);
		}//end fn
		
	});//end extend
	
})(jQuery);//�հ�