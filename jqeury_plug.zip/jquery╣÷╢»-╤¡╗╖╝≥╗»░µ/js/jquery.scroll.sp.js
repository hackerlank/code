//--------coding by chenyan
//2012.1.12

(function($) {
	
	jQuery.fn.extend({
		scrSpOn: function(boxScrH,boxSpeed,boxDelay,boxNoAuto) {		
			var _this=$(this);
			var boxCont,boxThis,boxUnit,boxOrg,boxDis,boxClone,boxTimer,boxIsTimer;
			resetThis();
			
			function resetThis(){
				boxScrH = boxScrH || false;//Ĭ�ϴ�ֱ
				boxDelay=boxDelay || 3000;
				boxNoAuto=boxNoAuto||false;
				boxCont=_this.children();
				boxThis=boxCont.children();			
				boxUnit=0;
				boxOrg=0;
				boxIsTimer=false;
				
				
				if(!boxScrH){
					boxSpeed=boxSpeed || 1000;
					boxThis.each(function(){
						boxOrg=boxUnit+=$(this).outerHeight(true);
					});	
					if(!boxNoAuto && boxUnit<_this.height()*2){
						boxClone=Math.floor( _this.height()*2/boxUnit);
						for(var i=1; i<=boxClone; i++){
							boxCont.append(boxThis.clone());
							boxUnit+=boxOrg; 
						}//end for	
					}//end if
					boxDis=boxUnit-_this.height();
					boxThis.width(_this.width());
				}//end if ��ֱ����
				else{
					boxSpeed=boxSpeed || 2000;
					boxThis.each(function(){
						boxOrg=boxUnit+=$(this).outerWidth(true);
					});	
					if(!boxNoAuto && boxUnit<_this.width()*2){
						boxClone=Math.floor( _this.width()*2/boxUnit);
						for(var i=1; i<=boxClone; i++){
							boxCont.append(boxThis.clone());
							boxUnit+=boxOrg; 
						}//end for	
					}//end if	
					boxDis=boxUnit-_this.width();
					boxCont.width(boxUnit);
				}//end else ˮƽ����
				
				boxThis=boxCont.children();
				//alert(boxThis.length);
				
				boxTimerFunc();
				_this.bind('mouseenter',boxMouseEnter);
				_this.bind('mouseleave',boxMouseLeave);								
			}//end func	
			
			function boxMouseEnter(){
				clearInterval(boxTimer);
				boxIsTimer=false;
			}//end func
			function boxMouseLeave(){
				if(!boxIsTimer){
					boxIsTimer=true;
					boxTimerFunc();
				}//end if
			}//end func
			
			function boxTimerFunc(){
				clearInterval(boxTimer);
				boxTimer=setInterval(btnRollFunc,boxDelay);
			}//end timer		
			
			function btnRollFunc(){
				if(!boxCont.is(":animated") && boxDis>0){	
					boxThis=boxCont.children();	
					if(!boxScrH){
						boxCont.animate({top:-boxThis.first().outerHeight(true)},boxSpeed,function(){boxThis.last().after(boxThis.first());boxCont.css("top",0);});	
					}//end if
					else{
						boxCont.animate({left:-boxThis.first().outerWidth(true)},boxSpeed,function(){boxThis.last().after(boxThis.first());boxCont.css("left",0);});
					}//end else
					
				}//end if(!boxCont.is(":animated"))
			}//end func

		}//end fn
		
	});//end extend
})(jQuery);//�հ�