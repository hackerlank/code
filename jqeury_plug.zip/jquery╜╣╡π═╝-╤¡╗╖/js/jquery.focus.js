//--------coding by chenyan
//2012.1.12

(function($) {
	
	jQuery.fn.extend({
		focusOn: function(boxScrV,boxSpeed,boxDelay,boxNoAuto) {
			var _this=$(this);	
			var boxMask,boxCont,boxThis,boxBtnL,boxBtnR,boxTot,boxWd,boxHt,boxMax,boxesWd,boxesHt,boxDis,boxUnit,boxTar,boxTimer,boxNow,boxBtnThis,boxRollDir,boxShowNum,boxIsTimer;
			resetThis();
			
			function resetThis(){
				boxSpeed=boxSpeed || 1000;
				boxDelay=boxDelay || 5000;
				boxScrV=boxScrV || false;
				boxNoAuto=boxNoAuto || false;	
				boxMask=_this.children(".boxMask");
				boxCont=boxMask.children();
				boxThis=boxCont.children();
				boxTot=boxThis.length;//ʵ���м���ͼ
				boxBtn=_this.children(".boxBtn");
				boxBtnL=_this.children(".boxBtnL");
				boxBtnR=_this.children(".boxBtnR");
				boxWd=_this.width();
				boxHt=_this.height();		
				boxMax;//һ���м���ͼ
				boxesWd;//�ܳ���
				boxesHt;//�ܸ߶�
				boxTar=0;
				boxNow=1;
				boxRollDir=-1;
				boxShowNum=1;
				boxIsTimer=false;
				
				boxThis.width(boxWd).height(boxHt);
				boxMask.width(boxWd).height(boxHt);
				boxCont.append(boxThis.first().clone());
				boxThis=boxCont.children();
				boxMax=boxThis.length;
				boxesWd=boxMax*boxWd;//�ܳ���
				boxesHt=boxMax*boxHt;//�ܸ߶�
				if(!boxScrV){boxCont.width(boxesWd);boxDis=boxesWd-boxWd;boxUnit=boxWd;}else{boxCont.height(boxesHt);boxDis=boxesHt-boxHt;boxUnit=boxHt;}
				
				for(var i=1; i<boxMax;i++){
					boxBtn.append('<span>'+i+'</span>');
				}//end for
				boxBtnThis=boxBtn.children();			
				
				_this.bind("goto",boxGoto);
				_this.bind("prev",boxPrev);
				_this.bind("next",boxNext);
				boxBtnThis.bind('click',boxBtnThis_click);
				boxBtnThis.bind('mouseenter',boxMouseEnter);
				boxBtnThis.bind('mouseleave',boxMouseLeave);
				boxBtnL.bind('click',boxBtnL_click);
				boxBtnL.bind('mouseenter',boxMouseEnter);
				boxBtnL.bind('mouseleave',boxMouseLeave);
				boxBtnR.bind('click',boxBtnR_click);
				boxBtnR.bind('mouseenter',boxMouseEnter);
				boxBtnR.bind('mouseleave',boxMouseLeave);
				boxThis.bind('mouseenter',boxMouseEnter);
				boxThis.bind('mouseleave',boxMouseLeave);
				boxTimerFunc();
				boxBtnThis.first().click();
			}//end func
			
			function boxPrev(event){
				if(!boxNoAuto){boxTimerFunc();}
				boxRollDir=1;
				btnRollFunc();
			}//end func
			
			function boxNext(event){
				if(!boxNoAuto){boxTimerFunc();}
				boxRollDir=-1;
				btnRollFunc();
			}//end func
			
			function boxGoto(event,value1){
				if(!boxCont.is(":animated") && boxDis>0){
					boxNow=value1;    
					if(!boxScrV){boxTar=-boxWd*(boxNow-1);}else{boxTar=-boxHt*(boxNow-1);}
					boxCont.stop(true);
					boxMotion();
					boxBtnChange();
				}//end if
			}//end func
			
			function boxBtnThis_click(event){
				var _obj=$(event.target);
				var _id=_obj.index();
				if(!boxCont.is(":animated") && boxDis>0){
					boxNow=_id+1;    
					if(!boxScrV){boxTar=-boxWd*(boxNow-1);}else{boxTar=-boxHt*(boxNow-1);}
					boxCont.stop(true);
					boxMotion();
					boxBtnChange();
				}//end if
			}//end func
			function boxBtnL_click(event){
				boxRollDir=1;
				btnRollFunc();
			}//end func
			function boxBtnR_click(event){
				boxRollDir=-1;
				btnRollFunc();
			}//end func	
			function boxMouseEnter(){
				clearInterval(boxTimer);
				boxIsTimer=false;
			}//end func
			function boxMouseLeave(){
				if(!boxIsTimer){
					boxIsTimer=true;
					boxTimerFunc();
				}//end if
			}//end func
			
			function boxTimerFunc(){
				if(!boxNoAuto){
					clearInterval(boxTimer);
					boxTimer=setInterval(btnRollFunc,boxDelay);
				}//end if
			}
			
			function btnRollFunc(){
			if(!boxCont.is(":animated") && boxDis>0){	
			
				boxTar+=boxUnit*boxRollDir;	
					if(boxRollDir==-1 && boxTar<-boxDis){
						if(!boxScrV){boxCont.css("left",0);}else{boxCont.css("top",0);}
						boxTar=-boxUnit;
					}//end if(boxRollDir==-1) 
					else if(boxRollDir==1 && boxTar>0){	
						if(!boxScrV){boxTar=-boxesWd+boxShowNum*boxUnit;boxCont.css("left",boxTar);}else{boxTar=-boxesHt+boxShowNum*boxUnit;boxCont.css("top",boxTar);}
						boxTar+=boxUnit;
					}//end else (boxRollDir==-1)
					
				boxMotion();
			   
			   if(boxRollDir==-1){
				  boxNow++;
				  boxNow=boxNow>boxTot?1:boxNow;
				}
			   else{
				  boxNow--;
				  boxNow=boxNow<1?boxTot:boxNow; 
				}
				
			   boxBtnChange();
			}//end if(!boxCont.is(":animated") && boxDis>0)
			}//end func
			
			
			function boxMotion(){
				if(!boxScrV){
					boxCont.animate({left:boxTar},boxSpeed,function(){if(boxNow==1){boxCont.css("left",0);};});
				}//end if
				else{
					boxCont.animate({top:boxTar},boxSpeed,function(){if(boxNow==1){boxCont.css("top",0);};});
				}//end else
			}//end func
			
			function boxBtnChange(){
				boxBtnThis.removeClass("now nor").eq(boxNow-1).addClass("now").siblings().addClass("nor");
			}//end func

		},//end fn
		
		focusGoto: function(boxId) {
			boxId=boxId||1;
			$(this).trigger('goto', [boxId]);
		},//end fn
		
		focusPrev: function() {
			$(this).trigger('prev');
		},//end fn
		
		focusNext: function() {
			$(this).trigger('next');
		}//end fn
		
	});//end extend
	
})(jQuery);//�հ�