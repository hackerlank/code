//--------coding by chenyan
//2012.1.11

(function($) {
	
	jQuery.fn.extend({
		scrRdOn: function(boxShowNum,boxScrV,boxSpeed,boxDelay,boxNoAuto,btnNoHide) {	
			var _this=$(this);
			var boxMask,boxCont,boxThis,boxBtnL,boxBtnR,boxWd,boxHt,boxMaskWd,boxMaskHt,boxMax,boxesWd,boxesHt,boxDis,boxUnit,boxTar,boxTimer,boxDir,boxIsTimer;
			resetThis();
			
			function resetThis(){	
				boxShowNum=boxShowNum || 1;
				boxDelay=boxDelay || 5000;
				boxSpeed=boxSpeed || 1000;
				boxScrV=boxScrV || false;//�Ƿ�ֱ�������
				boxNoAuto=boxNoAuto || false;
				btnNoHide=btnNoHide || false;
				
				boxMask=_this.children(".boxMask");
				boxCont=boxMask.children();
				boxThis=boxCont.children();
				boxBtnL=_this.children(".boxBtnL");
				boxBtnR=_this.children(".boxBtnR");
				boxWd=boxThis.first().outerWidth(true);
				boxHt=boxThis.first().outerHeight(true);
				boxMaskWd=boxShowNum*boxWd;//�ɰ���ȣ�Ӧ����boxWd��������
				boxMaskHt=boxShowNum*boxHt;//�ɰ�߶ȣ�Ӧ����boxWd������
				boxMax=boxThis.length;//һ���м���ͼ
				boxesWd=boxMax*boxWd;//�ܳ���
				boxesHt=boxMax*boxHt;//�ܸ߶�
				if(!boxScrV){boxMask.width(boxMaskWd);boxMask.height(boxHt);boxDis=boxesWd-boxMaskWd;boxCont.width(boxesWd);boxUnit=boxWd;}else{boxMask.width(boxWd);boxMask.height(boxMaskHt);boxDis=boxesHt-boxMaskHt;boxCont.height(boxesHt);boxUnit=boxHt;}
				boxTar=0;
				boxDir=-1;
				boxIsTimer=false;
				
				_this.bind("prev",boxPrev);
				_this.bind("next",boxNext);
				boxBtnL.bind('click',boxBtnL_click);
				boxBtnL.bind('mouseenter',boxMouseEnter);
				boxBtnL.bind('mouseleave',boxMouseLeave);
				boxBtnR.bind('click',boxBtnR_click);
				boxBtnR.bind('mouseenter',boxMouseEnter);
				boxBtnR.bind('mouseleave',boxMouseLeave);
				boxThis.bind('mouseenter',boxMouseEnter);
				boxThis.bind('mouseleave',boxMouseLeave);	
				boxTimerFunc();
				boxBtnChange();			
			}//end func
			
			function boxPrev(event){
				if(boxTar<0){
					if(!boxNoAuto){boxTimerFunc();}
					boxDir=1;
					btnRollFunc();
				}//end if
			}//end func
			
			function boxNext(event){
				if(boxTar>-boxDis){
					if(!boxNoAuto){boxTimerFunc();}
					boxDir=-1;
					btnRollFunc();
				}//end if
			}//end func
			
			function boxBtnL_click(event){
				if(boxTar<0){
					boxDir=1;
					btnRollFunc();
				}//end if
			}//end func
			function boxBtnR_click(event){
				if(boxTar>-boxDis){
					boxDir=-1;
					btnRollFunc();
				}//end if	
			}//end func	
			function boxMouseEnter(){
				clearInterval(boxTimer);
				boxIsTimer=false;
			}//end func
			function boxMouseLeave(){
				if(!boxIsTimer){
					boxIsTimer=true;
					boxTimerFunc();
				}//end if
			}//end func
			
			function boxTimerFunc(){
				if(!boxNoAuto){
					clearInterval(boxTimer);
					boxTimer=setInterval(btnRollFunc,boxDelay);
				}//end if
			}//end timer
			
			function btnRollFunc(){
				if(!boxCont.is(":animated") && boxDis>0){	
					boxTar+=boxUnit*boxDir;
					if(boxTar==-boxDis || boxTar==0){
						boxDir=-boxDir;	
					}//end if
				   boxMotion();
				   boxBtnChange();
				}//end if(!boxCont.is(":animated") && boxDis>0)
			}//end func
			
			function boxMotion(){
				if(!boxScrV){boxCont.animate({left:boxTar},boxSpeed);}//end if
				else{boxCont.animate({top:boxTar},boxSpeed);}//end else
			}//end func
			
			function boxBtnChange(){
				if(!btnNoHide){
					if(boxTar==0){boxBtnL.hide();boxBtnR.show();}else if(boxTar==-boxDis){boxBtnL.show();boxBtnR.hide();}else{boxBtnL.show();boxBtnR.show();}
				}//end if
			}//end func

		},//end fn
		
		scrRdPrev: function() {
			$(this).trigger('prev');
		},//end fn
		
		scrRdNext: function() {
			$(this).trigger('next');
		}//end fn
		
	});//end extend
	
})(jQuery);//�հ�
