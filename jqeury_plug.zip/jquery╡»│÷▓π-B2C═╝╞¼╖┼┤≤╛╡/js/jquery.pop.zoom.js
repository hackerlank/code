//--------coding by chenyan
//2012.1.12

(function ($) {	
	jQuery.fn.extend({
		popZoomOn: function() {		
			var _this=$(this);
			var zoomSrc,zoomRate,fadeTime,zoomPop,zoomPopDiv,zoomPopImg,zoomDiv,zoomLoad,zoomImgRate,zoomImgWd,zoomImgHt,mouseX,mouseY,posX,posY,isImgLoaded;
			resetThis();
			
			function resetThis(){		
				
				zoomPop=_this.children(".zoomPop");
				zoomThis=_this.children(".zoomThis");
				zoomDiv=_this.children(".zoomDiv");
				zoomLoad=_this.children(".zoomLoad");
				zoomPopDiv=zoomPop.children();
				zoomPopImg=zoomPopDiv.children('img');
				zoomThisImg=zoomThis.children('img');
				isImgLoaded=false;
				
				//alert(zoomThisImg.length);
				
				zoomImgRate=_this.width()/_this.height();
				zoomPop.css({"width":_this.width(),"height":_this.height(),"left":_this.width()+10});
				zoomThis.css({"width":_this.width(),"height":_this.height()});	
				zoomLoad.css({"top":Math.floor(_this.height()/2-zoomLoad.height()/2),"left":Math.floor(_this.width()/2-zoomLoad.width()/2)});	
							
				_this.bind("imgSet",imgSetFunc);
				zoomThis.bind("mouseenter",zoomThis_mouseenter);
				zoomThis.bind("mousemove",zoomThis_mousemove);
				zoomDiv.bind("mouseleave",zoomDiv_mouseleave);	
				zoomDiv.bind("mousemove",zoomDiv_mousemove);					
			}//end func
			
			function imgSetFunc(event,value1,value2,value3){
				zoomSrc=value1;
				zoomRate=value2;
				fadeTime=value3;
				isImgLoaded=false;
				
				zoomPopImg.remove();
				zoomThisImg.remove();
				zoomThis.append("<img/>");
				zoomPopDiv.append("<img/>");
				zoomPopImg=zoomPopDiv.children();
				zoomThisImg=zoomThis.children();				
				zoomLoad.show();
				zoomDiv.css({"width":zoomThis.width()/zoomRate-2,"height":zoomThis.height()/zoomRate-2});
				zoomDiv.hide();	
				zoomThisImg.hide();	
				zoomThisImg.attr("src",zoomSrc);
				zoomThisImg.one('load',zoomThisImg_Load);	
			}//end func
			
			function zoomDiv_mouseleave(event){
				zoomPop.hide();
				zoomDiv.hide();
			}//end func
			function zoomDiv_mousemove(event){
				mouseX = event.pageX;
				mouseY = event.pageY;
				zoomFollow();
			}//end func
			function zoomThis_mouseenter(event){
				mouseX = event.pageX;
				mouseY = event.pageY;
				if(isImgLoaded){
					zoomPop.show();
					zoomDiv.show();	
					zoomFollow();					
				}//end if	
				//alert("mouse enter");
			}//end func
			function zoomThis_mousemove(event){
				mouseX = event.pageX;
				mouseY = event.pageY;
				zoomFollow();
				if(isImgLoaded){
					zoomPop.show();
					zoomDiv.show();					
				}//end if	
			}//end func
			
			function zoomFollow(){
				mouseX=mouseX<zoomThis.offset().left?zoomThis.offset().left:mouseX;
				mouseX=mouseX>zoomThis.offset().left+zoomThis.width()?zoomThis.offset().left+zoomThis.width():mouseX;
				mouseY=mouseY<zoomThis.offset().top?zoomThis.offset().top:mouseY;
				mouseY=mouseY>zoomThis.offset().top+zoomThis.height()?zoomThis.offset().top+zoomThis.height():mouseY;
				posX=mouseX-zoomThis.offset().left-zoomDiv.width()/2;
				posY=mouseY-zoomThis.offset().top-zoomDiv.height()/2;
				posX=posX<=0?0:posX;
				posX=posX>=zoomThis.width()-zoomDiv.outerWidth()?zoomThis.width()-zoomDiv.outerWidth():posX;
				posY=posY<=0?0:posY;
				posY=posY>=zoomThis.height()-zoomDiv.outerHeight()?zoomThis.height()-zoomDiv.outerHeight():posY;
				zoomDiv.css({"left":posX,"top":posY});
				zoomPopDiv.css({"left":-posX*zoomRate,"top":-posY*zoomRate});				
			}//end func
			
			function zoomThisImg_Load(event){
				zoomLoad.hide();
				zoomImgWd=zoomThisImg.width();
				zoomImgHt=zoomThisImg.height();
				var imgSize1=new Array();
				imgSize1=mathAutoSizeMax([zoomImgWd,zoomImgHt],[zoomThis.width(),zoomThis.height()]);	
				zoomThisImg.width(imgSize1[0]).height(imgSize1[1]);
				zoomThisImg.css({"margin-left":Math.floor(zoomThis.width()/2-imgSize1[0]/2),"margin-top":Math.floor(zoomThis.height()/2-imgSize1[1]/2)});
				if(fadeTime<=1){zoomThisImg.show();}else{zoomThisImg.fadeIn(fadeTime);}	
				
				zoomPopImg.attr({"src":zoomSrc});
				zoomPopDiv.css({"width":zoomPop.width()*zoomRate,"height":zoomPop.height()*zoomRate});
				var imgSize2=new Array();
				imgSize2=mathAutoSizeMax([zoomImgWd,zoomImgHt],[zoomPopDiv.width(),zoomPopDiv.height()]);	
				zoomPopImg.width(imgSize2[0]).height(imgSize2[1]);
				zoomPopImg.css({"margin-left":Math.floor(zoomPopDiv.width()/2-imgSize2[0]/2),"margin-top":Math.floor(zoomPopDiv.height()/2-imgSize2[1]/2)});
				isImgLoaded=true;
			}//end func
			
			function mathAutoSizeMax(aryNum,aryMax){
				var aryNow=new Array()
				var aryRate = aryNum[0]/aryNum[1];
				aryNow[0] = aryMax[0];
				aryNow[1] = Math.round(aryNow[0]/aryRate);
				if(aryNow[1]>aryMax[1]){
					aryNow[1] = aryNow[1]<=aryMax[1] ? aryNow[1] : aryMax[1];
					aryNow[0] = Math.round(aryNow[1]*aryRate);
				}//end if
				return aryNow;
			}//end func
						
		},//end fn
		
		popZoomSet: function(zoomSrc,zoomRate,fadeTime) {
			zoomSrc=zoomSrc||"";
			zoomRate=zoomRate||3;
			fadeTime=fadeTime||250;
			$(this).trigger('imgSet', [zoomSrc,zoomRate,fadeTime]);
		}//end fn
						
	});//end extend		
}(jQuery));

(function ($) {
	$.event.special.load = {
		add: function (hollaback) {
			if ( this.nodeType === 1 && this.tagName.toLowerCase() === 'img' && this.src !== '' ) {
				// Image is already complete, fire the hollaback (fixes browser issues were cached
				// images isn't triggering the load event)
				if ( this.complete || this.readyState === 4 ) {
					hollaback.handler.apply(this);
				}
				// Check if data URI images is supported, fire 'error' event if not
				else if ( this.readyState === 'uninitialized' && this.src.indexOf('data:') === 0 ) {
					$(this).trigger('error');
				}
			}
		}
	};
}(jQuery));