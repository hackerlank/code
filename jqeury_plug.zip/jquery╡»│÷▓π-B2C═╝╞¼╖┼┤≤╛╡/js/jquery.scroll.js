//--------coding by chenyan
//2012.1.12

(function($) {
	
	jQuery.fn.extend({
		scrOn: function(boxScrV,boxSpeed,boxDelay,boxNoAuto) {	
			var _this=$(this);
			var boxMask,boxCont,boxThis,boxBtnL,boxBtnR,boxMax,boxDis,boxTimer,boxDir,boxIsTimer;			
			resetThis();
			
			function resetThis(){
				boxDelay=boxDelay || 5000;//�������
				boxSpeed=boxSpeed || 1000;//�����ٶ�
				boxScrV=boxScrV || false;//�Ƿ�ֱ�������
				boxNoAuto=boxNoAuto || false;//�Ƿ��Զ�����
				boxMask=_this.children(".boxMask");
				boxCont=boxMask.children();
				boxThis=boxCont.children();
				boxBtnL=_this.children(".boxBtnL");
				boxBtnR=_this.children(".boxBtnR");
				boxMax=boxThis.length;//һ���м���ͼ
				boxDir=-1;
				boxIsTimer=false;				
				boxDisFunc();
				
				_this.bind("prev",boxPrev);
				_this.bind("next",boxNext);				
				boxBtnL.bind('click',boxBtnL_click);
				boxBtnL.bind('mouseenter',boxMouseEnter);
				boxBtnL.bind('mouseleave',boxMouseLeave);
				boxBtnR.bind('click',boxBtnR_click);
				boxBtnR.bind('mouseenter',boxMouseEnter);
				boxBtnR.bind('mouseleave',boxMouseLeave);
				boxThis.bind('mouseenter',boxMouseEnter);
				boxThis.bind('mouseleave',boxMouseLeave);	
				boxTimerFunc();	
			}//end func
			
			function boxPrev(event){
				if(!boxNoAuto){boxTimerFunc();}
				boxDir=1;
				btnRollFunc();
			}//end func
			
			function boxNext(event){
				if(!boxNoAuto){boxTimerFunc();}
				boxDir=-1;
				btnRollFunc();
			}//end func

			function boxBtnL_click(event){
				boxDir=1;
				btnRollFunc();
			}//end func
			function boxBtnR_click(event){
				boxDir=-1;
				btnRollFunc();
			}//end func	
			function boxMouseEnter(){
				clearInterval(boxTimer);
				boxIsTimer=false;
			}//end func
			function boxMouseLeave(){
				if(!boxIsTimer){
					boxIsTimer=true;
					boxTimerFunc();
				}//end if
			}//end func
			
			function boxTimerFunc(){
				if(!boxNoAuto){
					clearInterval(boxTimer);
					boxTimer=setInterval(btnRollFunc,boxDelay);
				}//end if
			}//end timer
						
			function btnRollFunc(){
				if(!boxCont.is(":animated")){	
					boxDisFunc();
					if(boxDis>0){	
						boxThis=boxCont.children();
						if(!boxScrV){
							if(boxDir==-1){
								boxCont.animate({left:-boxThis.first().outerWidth(true)},boxSpeed,function(){boxThis.last().after(boxThis.first());boxCont.css("left",0);});
							}//end if
							else {
								boxThis.first().before(boxThis.last());
								boxThis=boxCont.children();
								boxCont.css("left",-boxThis.first().outerWidth(true));
								boxCont.animate({left:0},boxSpeed);
							}//end else if
						}//end if(!boxScrV)
						else{
							if(boxDir==-1){
								boxCont.animate({top:-boxThis.first().outerHeight(true)},boxSpeed,function(){boxThis.last().after(boxThis.first());boxCont.css("top",0);});
							}//end if
							else {
								boxThis.first().before(boxThis.last());
								boxThis=boxCont.children();
								boxCont.css("top",-boxThis.first().outerHeight(true));
								boxCont.animate({top:0},boxSpeed);
							}//end else if	
						}//end if(boxScrV)
						
					}//end if boxDis>0
				}//end if(!boxCont.is(":animated") && boxDis>0)
			}//end func
			
			function boxDisFunc(){
				var boxContWd=0;
				if(!boxScrV){
					boxThis.each(function(){
						boxContWd+=$(this).outerWidth(true);
					});	
					boxCont.width(boxContWd);
					boxThis.height(boxMask.height());	
					boxDis=boxCont.width()-boxMask.width();
				}else{
					boxThis.width(boxMask.width());
					boxDis=boxCont.height()-boxMask.height();
				}//end else
			}//end func

		},//end fn
		
		scrPrev: function() {
			$(this).trigger('prev');
		},//end fn
		
		scrNext: function() {
			$(this).trigger('next');
		}//end fn
		
	});//end extend
	
})(jQuery);//�հ�