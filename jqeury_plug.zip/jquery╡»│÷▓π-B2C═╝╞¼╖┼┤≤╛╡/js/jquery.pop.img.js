//--------coding by chenyan
//2012.1.12

(function ($) {	
	jQuery.fn.extend({
		popImgOn: function() {		
			var _this=$(this);
			var imgSrc,imgTit,imgTxt,fadeTime,popWdMax,popHtMax,popImg,popTit,popTxt,popClose,popLoad,popImgWd,popImgHt,popImg;
			resetThis();
			
			function resetThis(){

				popWdMax=$(window).width()*0.8;
				popHtMax=$(window).height()*0.8;
				popImg=_this.find(".popImg img");
				popTit=_this.find(".popTit");
				popTxt=_this.find(".popTxt");
				popLoad=_this.find(".load");
				popImgWd=0;
				popImgHt=0;
				
				_this.width(popWdMax);
								
				_this.bind("imgSet",imgSetFunc);
				$(window).bind('resize',imgReset);//end bind
				
			}//end func
			
			function imgSetFunc(event,value1,value2,value3,value4){			
				imgSrc=value1;
				imgTit=value2;
				imgTxt=value3;
				fadeTime=value4;	
				
				popImgWd=0;
				popImgHt=0;
				popImg.remove();
				_this.find(".popImg").append("<img/>");	
				popImg=	_this.find(".popImg img");	
				_this.popOn(Math.floor($(window).height()*0.05),'','',1);
				popImg.hide();
				popTit.html("").hide();
				popTxt.html("").hide();
				popLoad.show();		
				popImg.attr("src",imgSrc);
				popImg.one('load',imgReset);//end bind
			}//end func
			
			function imgReset(event){
					//alert("img resize");
					popLoad.hide();
					popWdMax=$(window).width()*0.8;
					popHtMax=$(window).height()*0.8;
					if(popImgWd==0){popImgWd=popImg.width();popImgHt=popImg.height();}
					var imgSize=new Array();
					imgSize=mathAutoSize([popImgWd,popImgHt],[popWdMax,popHtMax]);	
					popImg.attr({"width":imgSize[0],"height":imgSize[1]});
					if(imgTit!=""){popTit.show().html(imgTit);}
					if(imgTxt!=""){popTxt.show().html(imgTxt);}
					popImg.fadeIn(fadeTime);
					_this.width(imgSize[0]);
					_this.css({"left":Math.floor(($(window).width()-_this.outerWidth())/2),"top":Math.floor($(window).height()*0.05)});
			}//end func

			function mathAutoSize(aryNum,aryMax){
				var aryNow=new Array()
				var aryRate; 
				if(aryNum[0]>aryMax[0] || aryNum[1]>aryMax[1]){
						aryRate   = aryNum[0]/aryNum[1];
						aryNow[0] = aryNum[0]<=aryMax[0] ? aryNum[0] : aryMax[0];
						aryNow[1] = Math.round(aryNow[0]/aryRate);
						aryNow[1] = aryNow[1]<=aryMax[1] ? aryNow[1] : aryMax[1];
						aryNow[0] = Math.round(aryNow[1]*aryRate);
				}//end if
				else{
					aryNow[0]=aryNum[0];
					aryNow[1]=aryNum[1];
				}//end else	
				return aryNow;
			}//end func
						
		},//end fn
		
		popImgSet: function(src,tit,txt,fadeTime) {
			src=src||"";
			tit=tit||"";
			txt=txt||"";
			fadeTime=fadeTime||0;	
			$(this).trigger('imgSet', [src,tit,txt,fadeTime]);
		}//end fn
						
	});//end extend		
}(jQuery));

(function ($) {
	$.event.special.load = {
		add: function (hollaback) {
			if ( this.nodeType === 1 && this.tagName.toLowerCase() === 'img' && this.src !== '' ) {
				// Image is already complete, fire the hollaback (fixes browser issues were cached
				// images isn't triggering the load event)
				if ( this.complete || this.readyState === 4 ) {
					hollaback.handler.apply(this);
				}

				// Check if data URI images is supported, fire 'error' event if not
				else if ( this.readyState === 'uninitialized' && this.src.indexOf('data:') === 0 ) {
					$(this).trigger('error');
				}
			}
		}
	};
}(jQuery));