<?php
require_once("dataaccess.php");
require_once("game_title.class.php");
require_once 'saetv2.ex.class.php';

class CUser{
	
	//用户密码修改
	function clangePW($pw,$admin){
		$sqlStr= "update adminuser set password = md5('{$pw}') where username = '{$admin}'";
		$successUpdate = $GLOBALS['db_user']->ExecSqlNonQuery($sqlStr);
		if ($successUpdate)
		{
			echo "<div style='color:#f00; background:#ffffce; border:1px solid #f00; text-align:center; line-height:40px; margin-bottom:30px;'>密码修改成功</div>";
		}
		else
		{
			echo "<div style='color:#f00; background:#ffffce; border:1px solid #f00; text-align:center; line-height:40px; margin-bottom:30px;'>密码修改失败</div>";
		}
	}
	
	//获取 用户 的 鲜花数 和 鸡蛋数
	function getUserDC($uid){
		
		require_once("article.class.php");
		
		$artModel = new CArticle();

		$info = $this->getUserInfo($uid);
		if( $info['serverid'] ){
			$artTable = $artModel->getArticleTable( $info['serverid'] );
			if( $artTable ){
				$rs=$GLOBALS['db_gs']->FillArray("select sum(ding) as ding,sum(cai) as cai from {$artTable} where uid={$uid}");
				return array($rs[0]['ding'], $rs[0]['cai']);
			}
		}
		return false;
	}
	
	//获得 鸡蛋 鲜花 排名
	function getTopUser( $start ='', $end ='', $serverId=0, $country='' ){
			
		$sql="select * from server_article".($serverId?"  where serverid={$serverId} ":'');
		$server_art=$GLOBALS['db_gs']->FillArray($sql);
		$ding_result=array();
		$cai_result=array();
		
		$where='';
		if( $start ){
			$start.=" 00:00:00";
			$where.=" and ptime > '{$start}' ";
		}
		if( $end ){
			$end.=" 23:59:59";
			$where.=" and ptime <= '{$end}' ";
		}
		
		$sql_where='';
		if( $country ) $sql_where.=" and ucountry='{$country}' ";
		
		if( $server_art ){
			if( !$serverId ){
				foreach($server_art as $row){
					$sql="select sum(ding) as total,role,uaccount from article_{$row['id']} where open=1 {$where} group by uid order by total desc limit 1";
					$top=$GLOBALS['db_gs']->FillArray($sql);
					if( $top[0] ){
						$ding_result[]=$top[0];
					}
					
					$sql="select sum(cai) as total,role,uaccount from article_{$row['id']} where open=1 {$where} group by uid order by total desc limit 1";
					$top=$GLOBALS['db_gs']->FillArray($sql);
					if( $top[0] ){
						$cai_result[]=$top[0];
					}
				}
				usort($ding_result,array("CUser","orderbyTotal"));
				usort($cai_result,array("CUser","orderbyTotal"));				
			}
			else{
				$sql="select sum(ding) as total,role,uaccount from article_{$server_art[0]['id']} where open=1 {$where} {$sql_where} group by uid order by total desc limit 3";
				$ding_result=$GLOBALS['db_gs']->FillArray($sql);
				$sql="select sum(cai) as total,role,uaccount from article_{$server_art[0]['id']} where open=1 {$where} {$sql_where} group by uid order by total desc limit 3";
				$cai_result=$GLOBALS['db_gs']->FillArray($sql);
			}
			
			//var_dump( $ding_result );

			return array(array($ding_result[0],$ding_result[1],$ding_result[2]),array($cai_result[0],$cai_result[1],$cai_result[2]));
		}
	}
	
	function orderbyTotal( $a ,$b ){
	
		$c=$a['total']-$b['total'];
		return $c>0?-1:($c==0?0:1);
	}
	
	
	//读取申请用户
	function signupList($flag,$fromnum,$maxPerPage,$conf, $orderBy='rtime desc'){
		if($flag ==1 || $flag ==3)
		{
			$statusSql =" and status in (1,3) ";
		}elseif(4 == $flag){
		    $statusSql =" and status = 2 and sg_forever = 1 ";
		}else{
		    $statusSql =" and status ={$flag} ";
		}
		$sqlStr = "select * from user where 1=1 $statusSql $conf order by {$orderBy} limit {$fromnum},{$maxPerPage}";
		$total_sqlStr = "select count(*) as total from user where 1=1 $statusSql $conf ";
		
		$total_rs = $GLOBALS['db_user']->FillArray($total_sqlStr);
		$total=$total_rs[0]['total'];
		$info = $GLOBALS['db_user']->FillArray($sqlStr);
		
		require_once("article.class.php");
		
		$artModel = new CArticle();
		if( $info ){
			foreach( $info as $key => $row ){
				$info[$key]['server']= $artModel->getServerName($row['serverid']);
				if( $flag == 2 ){
					$tmp= $this->getUserDC( $row['uid'] );
					$info[$key]['ding']=$tmp[0];
					$info[$key]['cai']=$tmp[1];
				}
			}
		} 
		
		return array("info"=>$info,"total"=>$total);
	}
	
	// 读取等级信息
	function getLevel()
	{
		$sqlStr = "SELECT * from positioner ORDER BY position_num ASC";
		$info = $GLOBALS['db_gs']->FillArray($sqlStr);
		return $info;
	}
	
	// 根据等级，读取下一等级
	function getNextLevel($position_numV)
	{
		$sqlStr = "SELECT position_num from positioner WHERE position_num > '{$position_numV}' ORDER BY position_num ASC LIMIT 0,1";
		$info = $GLOBALS['db_gs']->FillArray($sqlStr);
		return $info[0]['position_num'];
	}
	
	//更新申请用户信息
	function updateUser($account,$role,$server,$country,$corps,$familia,$level,$game_position,$address,$qq,$email,$mobile,$online,$reason,$uid){
		$sqlStr= "update user set account = '{$account}', role = '{$role}',server = '{$server}',country = '{$country}',corps = '{$corps}',familia = '{$familia}',level = '{$level}',game_position = '{$game_position}',address = '{$address}',qq = '{$qq}',email = '{$email}',mobile = '{$mobile}',online = '{$online}',reason = '{$reason}' where uid = '{$uid}'";
		$successUpdate = $GLOBALS['db_user']->ExecSqlNonQuery($sqlStr);
		if ($successUpdate)
		{
			echo "<div style='color:#f00; background:#ffffce; border:1px solid #f00; text-align:center; line-height:40px; margin-bottom:30px;'>用户信息更新成功</div>";
		}
		else
		{
			echo "<div style='color:#f00; background:#ffffce; border:1px solid #f00; text-align:center; line-height:40px; margin-bottom:30px;'>用户信息更新失败</div>";
		}
	}
	
	
//更新用户状态
	function updateUserStatus($num,$uid){
		$sqlStr= "update user set status = {$num} where uid = '{$uid}'";
		$successUpdate = $GLOBALS['db_user']->ExecSqlNonQuery($sqlStr);

		//$GLOBALS['db_user']->ExecSqlNonQuery("update f_user set type={$status},is_hx={$houxuan} wher ");
		$tmp=array(
			1 =>array("status"=>1,"houxuan"=>1),
			2 =>array("status"=>1,"houxuan"=>0)
		);

		$status= $tmp[$num]['status'];
		$houxuan=$tmp[$num]['houxuan'];

		$rs = $GLOBALS['db_user']->FillArray("select account ,serverid,country,role from user where uid={$uid}");
		$account = $rs[0]['account'];
		$GLOBALS['db_user']->Update("f_user",array("type"=>$status,"is_hx"=>$houxuan,"serverid"=>$rs[0]['serverid'],"country"=>$rs[0]['country']),array("account"=>$account));
		
		if( $num == 2 ){
		
			$photoRs = $GLOBALS['db_user']->FillArray("select img_big_addr,img_addr,img_small_addr,img_pos from c_user where account='{$account}'");
			$photoRs = $photoRs[0];
			$UpdateField=array("img_big_addr"	=>$photoRs['img_big_addr'],
								"img_addr"		=>$photoRs['img_addr'],
								"img_small_addr"=>$photoRs['img_small_addr'],
								"img_pos"		=>$photoRs['img_pos'],
								"audit_time"	=>time());
			$UpdateWhere = array("account"=>$account);
			
			$GLOBALS['db_user']->Update("user", $UpdateField, $UpdateWhere);
			
		
			//更新以前的 角色 服务器 国家
			$GLOBALS['db_user']->Update("f_user",array("role"=>$rs[0]['role']),array("account"=>$account));
			$GLOBALS['db_user']->Update("c_user",array("rolename"=>$rs[0]['role'],"serverid"=>$rs[0]['serverid'],"country"=>$rs[0]['country']),array("account"=>$account));
		
			require_once(_ADMINROOT."/class/mes.class.php");
			$qa = new MES();
			$messageId = $qa->addMes("史官审核通过！","亲爱的玩家，恭喜您通过审核成为史官，征途2的历史等待着您来抒写激情！");
			
			$userData = $GLOBALS['db_user']->FillArray("select f.f_uid from f_user f left join user u on f.account=u.account where u.uid={$uid}");
			$qa->sentMes($userData[0]['f_uid'],$messageId);
			
			//更新 头像申请 史官标志位
			$GLOBALS['db_user']->Update("img_cache",array("type"=>1), array("account"=>$account));
			
			//设置 史官称号为 试用史官
			$this->setGameStatus($account, $rs[0]['serverid'], 6);
			
			//记入 永久用户信息
			$forever_user = $GLOBALS['db_user']->FillArray("select * from user where account='{$account}'");
			$forever_user = $forever_user[0];
			
			foreach( $forever_user as $key=>$value ){
				if( is_int($key) ){
					unset( $forever_user[$key] );
				}
			}
			
			unset( $forever_user['queue_created'] );
			$forever_user['status'] = $num;
			$forever_user['audit_time'] = time();
			$forever_user['created_int'] = time();
			
			$GLOBALS['db_user']->Insert('user_forever', $forever_user);
			
		}
	}
	
	//设置 史官称号
		/*
	$level_arr = array(
		1	=>"史官",
		2	=>"史令",
		3	=>"太史",
		4	=>"人气史官",
		5	=>"气人史官",
		6	=>"试用史官",
		0   =>"删除称号"
	);		
		*/	
	function setGameStatus($account, $srv_id, $level){
	
		require_once(_ADMINROOT."/class/server.class.php");
		require_once(_ADMINROOT."/class/config.class.php");
		require_once _ADMINROOT."/class/log.class.php";
		
		$model = new Cserver();
		$cconfigModel = new CConfig();
		
		$SrvInfo = $cconfigModel->getInfoBySrvId($srv_id);
		
		$log =new Log("sg_audit_addtitle");
		$date = date("Y-m-d H:i:s");
		$log->addBufLine("===================={$date}::{$account}============================");		
		
		$info = $GLOBALS['db_user']->FillArray("select role from user where account='{$account}'");
		$webRoleName = $info[0]['role'];
		
		$roleInfo = $model->getRolesByAccount($account, $SrvInfo['proid'], $webRoleName);
		if( !$roleInfo['err'] ){
		
			$log->addBufLine("更新称号为：试用史官");
			foreach( $roleInfo as $charID=>$field ){
				$model->updateLevel($field['uid'], $SrvInfo['proid'], $charID, $level);
			}
		}
		else{
			$log->addBufLine("没找到角色信息");
		}
		
		$log->writeBuf();
	}
	
	//计算相应用户总数
	function countNum($flag){
		$sqlStr = "select count(*) as total from user where status = {$flag}";
		$info = $GLOBALS['db_user']->FillArray($sqlStr);
		return $info[0]['total'];	
	}
	
	//删除根据uid删除史官用户数据
	function delUser($uid){
		$sqlStr = "delete from user where uid={$uid}";
		$GLOBALS['db_user']->ExecSqlNonQuery($sqlStr);
	}
	
	function delSGUserByAccount($uid){
		// 根据uid，读取到account
		$userArr = $this->getUserInfo($uid);
		$account = $userArr['account'];
		
		//更新 头像申请 史官标志位		
		
		$GLOBALS['db_user']->Update("img_cache", array("type"=>0), array("account"=>$account));
		
		// 更新f_user表状态
		$this->updateFuserTypeAndHx($account);
		// 在C_user表里面查询信息
		$c_user_arr = $this->readCUserInfoByAccount($account);
		
		if(count($c_user_arr)==0)
		{
			$this->insertCuserByUser($account);
		}else
		{		
			$this->updateCuserByUser($account);
		}
		
		$this->delUserByAccount($account);
		

		//删除史官称号
		$this->setGameStatus($account, $userArr['serverid'], 0);
	}
		
	//删除 所有待删区 史官
	function removeAllUser(){
	
		$users = $GLOBALS['db_user']->FillArray("select uid from user where status=5");
		
		foreach($users as $field){
			$this->delSGUserByAccount( $field['uid'] );
		}
		
		return count($users);
	}
	
	/**
	 * 更新史官和候选史官的f_user信息
	 * @param unknown_type $account
	 */
	function updateFuserTypeAndHx($account)
	{
		$sqlStr= "update f_user set type = 0,is_hx=0 where account = '{$account}'";
		$successUpdate = $GLOBALS['db_user']->ExecSqlNonQuery($sqlStr);		
	}
	
	
	/**
	 * 根据史官表的信息，更新普通用户表的信息
	 * @param unknown_type $account
	 */
	function updateCuserByUser($account)
	{
		// 根据账号，查到该史官的信息,
		$sgUserArr = $this->readUserInfoByAccount($account);
		$fUserInfo = $this->readFUserInfoByAccount($account);
		$updateSql = "UPDATE c_user 
							SET
							 nickname = '{$fUserInfo[0]['nickname']}'
							,rolename = '{$sgUserArr[0]['role']}'
							,serverid = '{$sgUserArr[0]['serverid']}'
							,country = '{$sgUserArr[0]['country']}'
							,phone = '{$sgUserArr[0]['mobile']}'
							,addr = '{$sgUserArr[0]['address']}'
							";
		if($sgUserArr[0]['img_addr'] !="")
		{
			$updateSql.= " ,img_addr = '{$sgUserArr[0]['img_addr']}' ";
		}
		if($sgUserArr[0]['img_big_addr'] !="")
		{
			$updateSql.= " ,img_big_addr = '{$sgUserArr[0]['img_big_addr']}' ";
		}
		if($sgUserArr[0]['img_small_addr'] !="")
		{
			$updateSql.= " ,img_small_addr = '{$sgUserArr[0]['img_small_addr']}' ";
		}
		if($sgUserArr[0]['img_pos'] !="")
		{
			$updateSql.= " ,img_pos = '{$sgUserArr[0]['img_pos']}' ";
		}
							
		$updateSql .=" WHERE account = '{$sgUserArr[0]['account']}' ";					
							
						
		$successUpdate = $GLOBALS['db_user']->ExecSqlNonQuery($updateSql);		
	}
	
/**
	 * 根据史官表的信息，插入普通用户表的信息
	 * @param unknown_type $account
	 */
	function insertCuserByUser($account)
	{
		// 根据账号，查到该史官的信息,
		$sgUserArr = $this->readUserInfoByAccount($account);
		$img_addr = $sgUserArr[0]['img_addr']==""?" ":$sgUserArr[0]['img_addr'];
		$img_big_addr = $sgUserArr[0]['img_big_addr']==""?" ":$sgUserArr[0]['img_big_addr'];
		$img_small_addr = $sgUserArr[0]['img_small_addr']==""?" ":$sgUserArr[0]['img_small_addr'];
		$img_pos = $sgUserArr[0]['img_pos']==""?" ":$sgUserArr[0]['img_pos'];
		$addr = $sgUserArr[0]['address'] == ""?" ":$sgUserArr[0]['address'];
		$fUserInfo = $this->readFUserInfoByAccount($account);
		
		if( !$fUserInfo[0]['f_uid'] ){
			
			$data=array(
				"account"	=>$account,
				"role"		=>$sgUserArr[0]['role'],
				"serverid"	=>$sgUserArr[0]['serverid'],
				"country"	=>$sgUserArr[0]['country']
			);
			$GLOBALS['db_user']->Insert('f_user',$data);
			$fUserInfo = $this->readFUserInfoByAccount($account);
		}
		
		$insertSql = "INSERT INTO c_user (c_uid                     ,account                     ,nickname                     ,rolename                 ,serverid                       ,country                       ,phone                         ,	addr     ,img_addr     ,img_big_addr      ,img_small_addr      ,img_pos      ,created) 
							       VALUES('{$fUserInfo[0]['f_uid']}','{$sgUserArr[0]['account']}','{$fUserInfo[0]['nickname']}','{$sgUserArr[0]['role']}','{$sgUserArr[0]['serverid']}'  ,'{$sgUserArr[0]['country']}'  ,'{$sgUserArr[0]['mobile']}'   ,'{$addr}' ,'{$img_addr}','{$img_big_addr}' ,'{$img_small_addr}' , '{$img_pos}',now())
							";
		$successUpdate = $GLOBALS['db_user']->ExecSqlNonQuery($insertSql);		
	}
	
	/**
	 * 根据账号删除史官数据
	 * @param $account
	 */
	function delUserByAccount($account)
	{
		$sqlStr = "delete from user where account='{$account}'";
		$GLOBALS['db_user']->ExecSqlNonQuery($sqlStr);
	}
	
	
	
	//根据 时间段 删除 申请用户
	function delFromDate($start, $end){
		if( !$start && !$end ) return -1;
		$where.="";
		if( $start ){
			$start.=" 00:00:00";
			$where=" and rtime> '{$start}' ";
		}
		if( $end ){
			$end.=" 23:59:59";
			$where.=" and rtime <= '{$end}' ";
		}
		if( $where ){
			$sql="delete from user where status=0 {$where}";
			$GLOBALS['db_user']->ExecSqlNonQuery($sql);
			return 0;
		}
	}
	
	//读取国史列表
	function readUserList(){
		$sqlStr = "select * from user where status = 2";
		$info = $GLOBALS['db_user']->FillArray($sqlStr);
		return $info;	
	}
	
	//读取新申请国史
	function readNewUserList($begintime, $endtime){
	
		$where="";
		if( $begintime ){
			$begintime.=" 00:00:00";
			$where.=" and rtime> '{$begintime}' ";
		}
		if( $endtime ){
			$endtime.=" 23:59:59";
			$where.=" and rtime <= '{$endtime}' ";
		}
		
		require_once("article.class.php");
		
		$sqlStr = "select * from user where status = 0 {$where}";
		$info = $GLOBALS['db_user']->FillArray($sqlStr);
		if( $info ){
			$artModel = new CArticle();
			foreach( $info as $key =>$row ){
				$info[$key]['server']=$artModel->getServerName( $row['serverid'] );
			}
		}
		return $info;
	}
	
	
	//用户奖励
	function updateUserRepoints($account,$num){
		$sqlStr= "update user set repoints = repoints{$num} where account = '{$account}'";
		$successUpdate = $GLOBALS['db_user']->ExecSqlNonQuery($sqlStr);	
		if($successUpdate){
			echo "<div style='color:#f00; background:#ffffce; border:1px solid #f00; text-align:center; line-height:40px; margin-bottom:30px;'>成功赏罚</div>";
		}
		
		//更新游戏内称号
		$gameModel = new game_title();
		$gameModel->updateLevel( $account );
	}
	
	//模糊查询用户名
	function readUserInfo($key){
		$sqlStr = "select * from user where role like '{$key}%' limit 20";
		$info = $GLOBALS['db_user']->FillArray($sqlStr);
		return $info;
	}
	
	//查询某服某国下国史
	function searchUser($server,$country,$btime,$etime){
	
		$sql_where='';
		if( !empty($country) ){
			$sql_where=" and country='{$country}' ";
		}
	
		if(empty($btime) || empty($etime)){
			$sqlStr = "select * from user where serverid = '{$server}' {$sql_where} and status =2 order by status desc";
			$info = $GLOBALS['db_user']->FillArray($sqlStr);
		}else{
			$sqlStr = "select * from user 
						where serverid = '{$server}' {$sql_where}
							and status = 2";
			$info = $GLOBALS['db_user']->FillArray($sqlStr);
			
			if( $info ){
				
				$tmp=$GLOBALS['db_gs']->FillArray("select id from server_article where serverid={$server}");
				$tableId=$tmp[0]['id'];
			
				foreach( $info as $key =>$user ){
					//var_dump($user);
					$count_sql="select count(*) as total from article_{$tableId}
									where ptime >= '{$btime} 00:00:00' and ptime <= '{$etime} 23:59:59' 
										and uid={$user['uid']}  and open=1";
					$tmp=$GLOBALS['db_gs']->FillArray($count_sql);
					$info[$key]['counts']=intval($tmp[0]['total']);
				}
				
				usort($info,array("CUser","orderByCounts"));
			}
		}
		
		return $info;
	}
	
	function orderByCounts($a, $b){
		$c=$a['counts']-$b['counts'];
		return $c>0?1:($c==0?0:-1);
	}
	
	//根据通行证查找用户信息
	function readUserInfoByAccount($account){
		$sqlStr = "select * from user where account = '{$account}'";
		$info = $GLOBALS['db_user']->FillArray($sqlStr);
		return $info;
	}
	
	//根据 uid 查询 用户信息
	function getUserInfo($uid){
		$info = $GLOBALS['db_user']->FillArray("select * from user where uid=$uid");
		return $info[0];
	}
	
//根据通行证查找用户信息
	function readFUserInfoByAccount($account){
		$sqlStr = "select * from f_user where account = '{$account}'";
		$info = $GLOBALS['db_user']->FillArray($sqlStr);
		return $info;
	}
	
//根据通行证查找普通用户用户信息
	function readCUserInfoByAccount($account){
		$sqlStr = "select * from c_user where account = '{$account}'";
		$info = $GLOBALS['db_user']->FillArray($sqlStr);
		return $info;
	}
	
	//读取 所有史官 的f_uid
	function getSG_fuid( $serverId=0 ){
	
		$where=$serverId?" serverid={$serverId} and ":"";
		return  $GLOBALS['db_user']->FillArray("select f_uid from f_user where {$where} type=1 and is_hx=0");
	}
	
	//读取 所有用户的f_uid
	function getUser_fuid(){
		return  $GLOBALS['db_user']->FillArray("select f_uid from f_user");
	}
	
	//读取 所有非史官用户的f_uid
	function getNoSG_fuid( $serverId=0 ){
	
		$where=$serverId?" serverid={$serverId} and ":"";
		return  $GLOBALS['db_user']->FillArray("select f_uid from f_user where {$where} type=0 or (type=1 and is_hx=1)");
	}
	
	//辞官申请
	function getsg_Remove_List(){
		$rs = $GLOBALS['db_user']->FillArray("select sr.*,u.serverid,u.country,u.account from sg_remove_pre sr inner join user u on sr.uid=u.uid");
		
		if( $rs  ){
			foreach ( $rs as $key =>$row ){
				$tmp = $GLOBALS['db_gs']->FillArray("select count(*) as total from article where uaccount='{$row['account']}'");
				$rs[$key]['art_num'] = (int) $tmp[0]['total'];
			}
		}
		
		return $rs;
	}
	
	//删除 辞官请求
	function deleteRemoveRequest($uid){
		
		$GLOBALS['db_user']->ExecSqlNonQuery("delete from sg_remove_pre where uid='{$uid}'");
	}
	
	//修改 史官的角色名
	function updateRole($account, $role){
		$GLOBALS['db_user']->Update('user',array("role"=>$role), array("account"=>$account));
		$GLOBALS['db_user']->Update('f_user',array("role"=>$role), array("account"=>$account));
	}
	
	//查询 符合文采值条件的史官
	function getInfoByNumber($srv_id, $min, $max){
		
		$min = (int) $min;
		$max = (int) $max;
		
		$having_where='';
		if( $min > 0 ){
			$having_where=" and credit>{$min} ";
		}
		if( $max > 0 ){
			$having_where.=" and credit<{$max} ";
		}
		
		$sql="select account,(points+repoints) as credit,serverid from user where serverid={$srv_id} and status=2 having 1 {$having_where}";

		return $GLOBALS['db_user']->FillArray($sql);
	}
	
	//待删除史官 列表
	function getRemoveUserList( $where, $start=0, $pageSize=15 ){
		
		$sql_where='';
		if( $where['server'] ){
			$sql_where.=" and serverid={$where['server']} ";
		}
		if( $where['country'] ){
			$sql_where.=" and  country='{$where['country']}' ";
		}
		if( $where['account'] ){
			$sql_where.=" and  account='{$where['account']}' ";
		}
		
		$sqlStr = "select * from user where status=5 {$sql_where} order by serverid asc limit {$start},{$pageSize}";
		$total_sqlStr = "select count(*) as total from user where status=5 {$sql_where}";
		
		$total_rs = $GLOBALS['db_user']->FillArray($total_sqlStr);
		$total=$total_rs[0]['total'];
		$info = $GLOBALS['db_user']->FillArray($sqlStr);
		
		require_once("article.class.php");
		
		$artModel = new CArticle();
		if( $info ){
			foreach( $info as $key => $row ){
				$info[$key]['server']= $artModel->getServerName($row['serverid']);

				$tmp= $this->getUserDC( $row['uid'] );
				$info[$key]['ding']=$tmp[0];
				$info[$key]['cai']=$tmp[1];
			}
		}
		
		return array("info"=>$info,"total"=>$total);
	}
	
	//恢复为史官
	function restoreSg( $uid ){
		
		$userInfo = $GLOBALS['db_user']->FillArray("select account,serverid from user where uid={$uid}");
		$account = $userInfo[0]['account'];
		
		$GLOBALS['db_user']->Update("user", array("status"=>2), array("account"=>$account));
		$GLOBALS['db_user']->Update("f_user", array("type"=>1), array("account"=>$account));
		
		if( getenv('GS_ENV') != 'local' ){
		
			//恢复为 试用史官
			$this->setGameStatus($account, $userInfo[0]['serverid'], 6);
		}
	}
	
	
	/*
		永久用户信息相关
	*/
	
	function getForeverUser( $where, $start, $pageSize, $listall=0 ){
	
		$sql_where='';
		if( $where['account'] ){
			$sql_where.=" and account='{$where['account']}' ";
		}
		
		if( $where['mail'] ){
			$sql_where.=" and email !='' ";
		}
		
		if( $where['qq'] ){
			$sql_where.=" and qq !='' ";
		}

		if( $where['mail'] ){
			$sql_where.=" and email !='' ";
		}

		$key_arr=array(
			"account"	=>"账号",
			"role"		=>"角色",
			"address"	=>"地址",
			"qq"		=>"QQ",
			"email"		=>"邮箱",
			"mobile"	=>"电话",
			"reason"	=>"申请原因",
			"corps"		=>"帮会",
			"familia"	=>"家族",
		);
		foreach( $key_arr as $k1=>$v1 ){

			if ( $where["k".$k1] != '' ){
				$value = $where["k".$k1];
				$sql_where.=" and {$k1} like '%{$value}%' ";
				break;
			}
		}
	
		if( !$listall ){
			$sql=" select * from user_forever where 1 {$sql_where} order by id desc limit {$start}, {$pageSize}";
			$total = $GLOBALS['db_user']->FillArray("select count(*) as total from user_forever where 1 {$sql_where}");
			$info = $GLOBALS['db_user']->FillArray($sql);
		}
		else{
			$info = $GLOBALS['db_user']->FillArray( "select * from user_forever where 1 {$sql_where} order by id desc" );
		}
		
		require_once("article.class.php");
		
		$artModel = new CArticle();
		if( $info ){
			foreach( $info as $key => $row ){
				$info[$key]['server']= $artModel->getServerName($row['serverid']);
			}
		}		
		
		if( !$listall ){
			return array("list"=>$info, "total"=>$total[0]['total']);
		}
		else{
			return $info;
		}
	}
	
	function getSgApplyQueue( $srvId, $country, $account ){
	
		require_once(_ADMINROOT."/class/config.class.php");
		
		$sql_where = '';
		if( $srvId ) $sql_where=" and q.serverid={$srvId} ";
		if( $country ) $sql_where.=" and q.country='{$country}' ";
		if( $account ) $sql_where.=" and q.account='{$account}' ";
		
		global $small_country;
		$sql=" select q.*,u.role from queue_apply q left join user u on q.uid=u.uid where 1 {$sql_where} ";
		$rs = $GLOBALS['db_user']->FillArray( $sql );
		
		$cconfigModel = new CConfig();
		
		if( $rs ){
			foreach( $rs as $key=>$row ){
				$rs[$key]['number'] = $key+1;
				$rs[$key]['countryname'] = $small_country[$row['country']];
				$rs[$key]['servername'] = $cconfigModel->getNameByServerId( $row['serverid'] );
			}
		}
		return $rs;
	}
	
	//通过用户ID添加永久史官 by shenjian@ztgame.com 2012-02-02
	function addForeverById($uid) {
	    $GLOBALS['db_user']->ExecSqlNonQuery("update user set  sg_forever=1 where uid='{$uid}'");
	}
	//通过用户ID删除永久史官 shenjian@ztgame.com 2012-02-02
	function delForeverById($uid) {
	    $GLOBALS['db_user']->ExecSqlNonQuery("update user set  sg_forever=0 where uid='{$uid}'");
	}
	//通过用户名添加永久用户 by shenjian@ztgame.com 2012-02-02
	function addForeverByName($name) {
	    $info = $GLOBALS['db_user']->FillArray("select * from user where account='{$name}' and status = 2");
	    if (empty($info[0])){
	        return "改史官不存在，请查证后重试";
	    }else{
	        $this->addForeverById($info[0]['uid']);
	        return "添加永久史官成功";
	    }
	}
	/**
	 * 获取用户绑定的access_token
	 */
	function get_wb_access_token($account)
	{
	    $res = $GLOBALS['db_user']->FillArray("select access_token from c_user where account='{$account}'");
	    return empty($res[0]['access_token'])?0:$res[0]['access_token'];
	}
	/**
	 * 同步国史到微博
	 * @param string $account 巨人通行证
	 * @param string $table 国史文章表名
	 * @param int $aid 国史ID
	 */
	function send_to_weibo($account,$table,$aid)
	{
	    $access_token = $this->get_wb_access_token($account);
	    if (!$access_token) return false;
	    $wb = new SaeTClientV2(WB_AKEY, WB_SKEY, $access_token);
	    
	    $res = $GLOBALS['db_gs']->select($table, "atitle, userver, content", array('aid'=>$aid,'uaccount'=>$account));
	    $is_share = $GLOBALS['db_gs']->select("article_pk","is_share",array('id'=>$aid));
	    if (!$is_share[0]['is_share']){
	        return false;
	    }
	    preg_match('/src="(http.*.[(jpg)|(png)|(jpeg)])"/', $res[0]['content'], $ress);
	    $msg = WB_SHARETEXT."《".$res[0]['atitle']."》 http://gszt2.ztgame.com/article.php?aid={$aid}&s={$res[0]['userver']}";
        if (empty($ress)){
            $wb->update($msg);
        }else {
            $wb->upload($msg, $ress[1]);
        }
	}	
	
}
?>