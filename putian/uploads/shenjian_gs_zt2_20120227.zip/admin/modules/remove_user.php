<?php 
	error_reporting(0);
	require_once("config.php");
	require_once(_ADMINROOT."/class/user.class.php");
	require_once(_ADMINROOT."/class/config.class.php");
	$user = new CUser();
	$config = new CConfig();
	$reason_arr = array(0=>'暂无',1=> '7天未发布新史记',2=>'每月基础篇数未完成',3=>'史官转国');
	//define('SQL_DEBUG',1);

function echodiv($txt){
	return "<div style='color:#f00; background:#ffffce; border:1px solid #f00; text-align:center; line-height:40px; margin-bottom:30px;'>{$txt}</div>";
}	
	
	$conf = null;
	if (! isset ( $_POST ['__EVENTTARGET'] )) {
	//---
	
		
	} else {		
		switch ($_POST ['__EVENTTARGET']) {
			case "restore" :
				$list = $_POST['userid'];

				foreach ($list as $key=>$value){
					$user ->restoreSg($key);
				}
				echo echodiv("成功恢复了".count($list)." 个史官");
				break;

			case "delete_user" :
				$list = $_POST['userid'];

				foreach ($list as $key=>$value){
					$user->delSGUserByAccount($key);
				}
				echo echodiv("成功删除了".count($list)." 个史官");
				break;
			case "delete_alluser":
			
				set_time_limit(300);
				
				$number = $user->removeAllUser();
				echo echodiv("成功删除了".$number." 个史官");
				
				break;
		}
	}
	$currentPage = $_GET['page']?$_GET['page']:1; //当前页码
	$maxPerPage = 10; //每页显示显示条数
	$start = ($currentPage-1)*$maxPerPage;
	
	$data = $_REQUEST;
	
	$where=array(
		"server"	=>$data['server'],
		"country"	=>$data['country'],
		"account"	=>$data['account'],
	);
	
	$url_where="server={$data['server']}&country={$data['country']}&account={$data['account']}";
	
	$result = $user ->getRemoveUserList( $where, $start, $maxPerPage );
	
	$info = $result['info'];

	$levelArr = $user->getLevel();
	$serverList = $config->serverOpenList();
	
	if( !$_COOKIE['user_show_type'] ){
		setcookie('user_show_type','less');
	}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml">
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
<title></title>
<link type="text/css" rel="stylesheet" href="/css/style.css" /> 
<script type="text/javascript" src="/scripts/jquery.min.js"></script>
<script type="text/JavaScript" src="/scripts/date.js"></script>
<script type="text/JavaScript" src="/scripts/jquery.cookie.js"></script>
<script type="text/javascript"> 
    $(document).ready(function(){ 
		$('.user_input').focus(function(){
			$('.user_input').css("background","none");
			$(this).css("background","#ffffce");
		});

		$('#all_checkbox').click(function(){
			$(".c_box").attr("checked", true);
		});

		$('#none_checkbox').click(function(){
			$(".c_box").attr("checked", false);
		});

		$('#toggle_checkbox').click(function(){
			$(".c_box").each(function() {
                $(this).attr("checked", !$(this).attr("checked"));
            });
		});
		
    });
</script> 
<style>
#userlist table{ font-size:12px; border-collapse:collapse;}
#userlist table tr{ height:30px;}
#userlist table td{ border:1px #999 solid; padding:0 10px;}
</style>
</head>
<body>

<div id="user_list">
<div style=" margin-bottom:20px;">
	<form method="get" action="">
	服务器：
	<select id="server" name="server">
		<option value="">全部</option>
		<?php foreach ($serverList as $i=>$v):?>
		<option value="<?php echo $v['id']?>" <?php echo $v['id'] == $data['server']?"selected='selected'":null;?>><?php echo $v['servername'];?></option>
		<?php endforeach;?>
	</select>
	国家:<select name="country" id="country">
			<option value="">全部</option>
			<option value="song">宋</option>
			<option value="wei">魏</option>
			<option value="qi">齐</option>
			<option value="yan">燕</option>
			<option value="tang">唐</option>
			<option value="han">汉</option>
			<option value="zhao">赵</option>
			<option value="wu">吴</option>
			<option value="qin">秦</option>
			<option value="chu">楚</option>
		</select>
	账号：<input type="text" name="account" value="<?= $data['account'];?>"  />
	<input value="查询" type="submit" class="btn" />
	</form>
</div>

<form method="post" action="" name="Form1" id="Form1">
	<input type="hidden" name="__EVENTTARGET" value="" />
	<input type="hidden" name="__EVENTARGUMENT" value="" />
	<script type="text/javascript">
		function __doPostBack(eventTarget, eventArgument){
			var theform;
		  	if(window.navigator.appName.toLowerCase().indexOf("netscape") > -1){
				theform = document.forms["Form1"];
			}else{
				theform = document.Form1;
			}
			theform.__EVENTTARGET.value = eventTarget.split("$").join(":");
			theform.__EVENTARGUMENT.value = eventArgument;
			theform.submit();
		}
	</script>

<div style=" margin-bottom:20px;">
	<input onclick="__doPostBack('restore','')" value="恢复为史官" type="button" class="btn1" />
	<input onclick="if(confirm('你确定删除该用户吗？')){__doPostBack('delete_user','');}" value="删除所选" type="button" class="btn1" />
	<input onclick="if(confirm('你确定删除所有用户吗？')){__doPostBack('delete_alluser','');}" value="删除所有" type="button" class="btn1" />
	&nbsp;&nbsp;&nbsp;&nbsp;
<input value="全选" id="all_checkbox" type="button" class="btn1" />  <input value="全不选" id="none_checkbox" type="button" class="btn1" />  <input value="反选" id="toggle_checkbox" type="button" class="btn1" /> 
&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" id="showall" value="全部列显示" class="btn1" /> <input type="button" id="showless" value="简约列显示" class="btn1" />
&nbsp;&nbsp;&nbsp;&nbsp;
</div>
<div id="userlist">
	<table id="list_table">
		<tr style=" " class="newtop">
			<td width="10px"></td>
			<td width="60">帐号</td>
			<td>角色名</td>
			<td>服务器</td>
			<td>国家</td>
			<td>等级</td>			
			<td>鲜花</td>
			<td>鸡蛋</td>
			<td>申请时间</td>
			<td>取消原因</td>
			<td>取消时间</td>
			<td>帮会</td>
			<td>家族</td>
			<td>游戏内职位</td>
			<td>所在省市</td>
			<td>QQ</td>
			<td>电子邮件</td>
			<td>手机</td>
			<td>每日在线时长</td>
		</tr>
		<?php		
		for($i=0;$i<count($info);$i++){
		?>
			<tr>	
				<td><input class="c_box" type="checkbox" name="userid[<?php echo $info[$i]['uid']; ?>]"  /></td>	
				<td><?php echo $info[$i]['account']; ?></td>
				<td><?php echo $info[$i]['role']; ?></td>
				<td><?php echo $info[$i]['server']; ?></td>
				<td><?php echo $inc_contoryArr[$info[$i]['country']];?></td>
				<td><?php echo $info[$i]['level']; ?></td>	
			<td><?php echo $info[$i]['ding']; ?></td>
			<td><?php echo $info[$i]['cai']; ?></td>
			
				<td><?php echo $info[$i]['rtime']; ?></td>
				<td><?php echo $reason_arr[$info[$i]['del_reason']]; ?></td>
				<td><?php echo $info[$i]['del_time']; ?></td>

				<td><?php echo $info[$i]['corps']; ?></td>
				<td><?php echo $info[$i]['familia']; ?></td>				
				<td><?php echo $info[$i]['game_position']; ?></td>
				<td><?php echo $info[$i]['address']; ?></td>
				<td><?php echo $info[$i]['qq']; ?></td>
				<td><?php echo $info[$i]['email']; ?></td>
				<td><?php echo $info[$i]['mobile']; ?></td>
				<td><?php echo $info[$i]['online']; ?></td>					
			</tr>
		<?php 
			}
		?>
	</table>
	</div>
</div>
</form>

<?php 	
	//$num = $user -> countNum($flag);
	$num = $result['total'];
	//$num = count($nums);
	if($num > $maxPerPage){
		$config->cutPage("remove_user.php?".$url_where,$num,$currentPage,$maxPerPage);
	}
?>
</body>
<script type="text/JavaScript" src="/scripts/jqr.js"></script>
<script language="javascript">

$("#country").val('<?= $_REQUEST['country']?>');

$("#showall").click(
	function(){
		showField('all');
	}
);
$("#showless").click(
	function(){
		showField('less');
	}
);
	var lessFiled={"帐号":1,"角色名":1,"申请时间":1,"服务器":1,"国家":1,"取消时间":1,"取消原因":1};
	
	function showField(ShowType){
		
		var table=document.getElementById('list_table');
		var rows=table.rows.length;
		var hiddencols=[];
		if( rows >1 ){
			var row=table.rows[0];
			var cols=row.cells.length;
			for(c=0;c<cols;c++){
				if( row.cells[c].innerHTML!='' ){
					if( lessFiled[row.cells[c].innerHTML] == undefined ){
						hiddencols.push(c);
					}
				}
			}			
		}

		var display=(ShowType=="less"?"none":'');
		
		if( hiddencols.length > 0 ){
			for(c=0;c<rows;c++){
				for(d=0;d<hiddencols.length;d++){
					table.rows[c].cells[hiddencols[d]].style.display=display;
				}
			}
		}
		$("#show"+ShowType).css({"background-color":"#666666","color":"#fff"});
		$("#show"+(ShowType=="less"?"all":"less")).css({"background-color":""});
		
		$.cookie('user_show_type',ShowType);
	}
	
if( $.cookie("user_show_type") ){
	showField($.cookie("user_show_type"));	
}
</script>

</html>