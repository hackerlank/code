<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: discuz_version.php 30869 2012-06-27 07:11:34Z cnteacher $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!defined('DISCUZ_VERSION')) {
	define('DISCUZ_VERSION', 'X2');
	define('DISCUZ_RELEASE', '20120628');
}

?>